%RUN_ALL_TESTS Low-cost verification suite for the active package API.
root = fileparts(fileparts(mfilename('fullpath')));
addpath(root);
startup_HOI();

fprintf('\nRunning HOI density-formulation tests...\n');
test_results.fourier_derivative = test_fourier_derivative();
test_results.fourier_prolongation = test_fourier_prolongation();
test_results.projection_equivalence = test_projection_equivalence();
test_results.gradient_consistency = test_gradient_consistency();
test_results.hessian_consistency = test_hessian_consistency();
test_results.discrete_convexity = test_discrete_convexity();
test_results.spg_feasibility = test_spg_feasibility();
test_results.spg_descent = test_spg_descent();
test_results.pdas_small_problem = test_pdas_small_problem();
test_results.entropy_prox_mass = test_entropy_prox_mass();
test_results.entropy_prox_optimality = test_entropy_prox_optimality();
test_results.entropy_prox_eta_zero_limit = test_entropy_prox_eta_zero_limit();
test_results.entropy_gradient_hessian = test_entropy_gradient_hessian();
test_results.entropy_newton_small_problem = test_entropy_newton_small_problem();
fprintf('All HOI tests passed.\n');
