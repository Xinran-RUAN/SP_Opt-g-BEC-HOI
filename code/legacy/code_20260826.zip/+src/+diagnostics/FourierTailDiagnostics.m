function diagnostic = FourierTailDiagnostics(rho)
%FOURIERTAILDIAGNOSTICS Normalized Fourier coefficients and tail energies.

[modes, coefficients] = src.discretization.ps.FourierCoefficients(rho);
power = abs(coefficients) .^ 2;
totalPower = sum(power);
if totalPower == 0
    quarter = 0;
    third = 0;
else
    N = numel(rho);
    quarter = sum(power(abs(modes) >= N / 4)) / totalPower;
    third = sum(power(abs(modes) >= N / 3)) / totalPower;
end
diagnostic.modes = modes;
diagnostic.rho_hat = coefficients;
diagnostic.rho_hat_abs = abs(coefficients);
diagnostic.tail_ratio_quarter = quarter;
diagnostic.tail_ratio_third = third;
end
