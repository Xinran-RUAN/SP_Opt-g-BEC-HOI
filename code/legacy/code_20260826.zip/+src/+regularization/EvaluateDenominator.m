function [s, ds, d2s, info] = EvaluateDenominator(rho, reg)
%EVALUATEDENOMINATOR Evaluate s_epsilon and its first two derivatives.
%
% The active definitions have physical domain rho >= 0. Values that are
% negative only at roundoff scale are clipped to zero; material negative
% values are rejected rather than extending the regularization.

[reg, info] = src.regularization.Validate(reg);
if ~isreal(rho) || any(~isfinite(rho(:)))
    error('src:regularization:EvaluateDenominator:InvalidDensity', ...
        'rho must be finite and real.');
end
roundoff = 100 * eps(max(1, max(abs(rho(:)))));
if any(rho(:) < -roundoff)
    error('src:regularization:EvaluateDenominator:NegativeDensity', ...
        'Active regularizations are defined only for rho >= 0.');
end
r = max(rho, 0);

switch reg.name
    case 'shift_smooth'
        s = r + reg.epsilon;
        ds = ones(size(r));
        d2s = zeros(size(r));
    otherwise
        m = sscanf(reg.name, 'piecewise_c%d');
        d = reg.transition_width;
        inside = (r <= d);
        z = 1 - r(inside) / d;

        s = reg.epsilon + r + d / (m + 1);
        ds = ones(size(r));
        d2s = zeros(size(r));
        s(inside) = reg.epsilon + r(inside) + ...
            d / (m + 1) .* (1 - z .^ (m + 1));
        ds(inside) = 1 + z .^ m;
        d2s(inside) = -(m / d) .* z .^ (m - 1);
end

if any(s(:) <= 0) || any(d2s(:) > 100 * eps(max(1, max(abs(d2s(:))))))
    error('src:regularization:EvaluateDenominator:InvariantFailure', ...
        'The denominator must be positive and concave.');
end
end
