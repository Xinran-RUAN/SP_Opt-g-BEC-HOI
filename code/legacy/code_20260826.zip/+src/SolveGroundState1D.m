function result = SolveGroundState1D(problem, rho0, solver)
%SOLVEGROUNDSTATE1D Convex minimizer followed by optional KKT polish.

requiredProblemFields = {'grid', 'plan', 'V', 'beta', 'delta', ...
    'mass', 'regularization'};
if ~isstruct(problem) || ~all(isfield(problem, requiredProblemFields))
    error('src:SolveGroundState1D:InvalidProblem', ...
        'problem is missing required fields.');
end
if numel(problem.V) ~= problem.grid.N || problem.plan.N ~= problem.grid.N
    error('src:SolveGroundState1D:SizeMismatch', ...
        'Grid, plan, and potential sizes must agree.');
end
[problem.regularization, regularizationInfo] = ...
    src.regularization.Validate(problem.regularization);
if ~regularizationInfo.is_convex_preserving
    error('src:SolveGroundState1D:NonconvexRegularization', ...
        'The active solver accepts only convexity-preserving regularizations.');
end

problem = applyEntropyDefaults(problem);
solver = applySolverDefaults(solver);
entropyActive = problem.entropy.enabled && problem.entropy.eta > 0;
if entropyActive && strcmpi(solver.name, 'spg')
    error('src:SolveGroundState1D:SPGNotAvailableForEntropy', ...
        'Classic SPG is retained only for eta=0; use fista_cd or ista.');
end
rho0 = projectInitial(rho0, problem, solver);
printMainHeader(solver);

switch lower(char(solver.name))
    case 'ista'
        [rhoMain, mainDiagnostics, mainHistory] = ...
            src.solvers.ISTA(problem, rho0, solver);
    case 'spg'
        [rhoMain, mainDiagnostics, mainHistory] = ...
            src.solvers.SPG(problem, rho0, solver);
    case {'fista_cd', 'fista-cd'}
        solver.name = 'fista_cd';
        [rhoMain, mainDiagnostics, mainHistory] = ...
            src.solvers.FISTACD(problem, rho0, solver);
    otherwise
        error('src:SolveGroundState1D:UnknownSolver', ...
            'Unknown solver "%s".', solver.name);
end

mainState = src.solvers.EvaluateState(rhoMain, problem, solver);
polishResult = emptyPolishResult( ...
    rhoMain, mainState, solver.polish.pg_tol);
switch lower(char(solver.polish_mode))
    case 'none'
        shouldPolish = false;
    case 'always'
        shouldPolish = true;
    case 'if_needed'
        shouldPolish = mainState.pg_residual > solver.polish.pg_tol;
    otherwise
        error('src:SolveGroundState1D:UnknownPolishMode', ...
            'polish_mode must be none, always, or if_needed.');
end

if shouldPolish && ~mainDiagnostics.failed
    polishOptions = solver.polish;
    polishOptions.projection_name = solver.projection_name;
    polishOptions.projection_tol = solver.projection_tol;
    polishOptions.residual_step = solver.residual_step;
    polishOptions.display = solver.display;
    if entropyActive
        if solver.display
            fprintf('Entropy Newton   pg_res      kkt_res     GMRES  step\n');
        end
        polishResult = src.solvers.PolishEntropyNewton( ...
            rhoMain, problem, polishOptions);
    else
        if solver.display
            fprintf('PDAS iter   pg_res      kkt_res     active  GMRES  step\n');
        end
        polishResult = src.solvers.PolishPDAS( ...
            rhoMain, problem, polishOptions);
    end
end

rhoFinal = polishResult.rho;
finalState = src.solvers.EvaluateState(rhoFinal, problem, solver);
diagnostics = mainDiagnostics;
diagnostics.main_solver = upper(strrep(solver.name, '_', '-'));
diagnostics.main_iterations = mainDiagnostics.iterations;
diagnostics.main_elapsed_time = mainDiagnostics.elapsed_time;
diagnostics.main_converged = mainDiagnostics.converged;
diagnostics.energy_before_polish = mainState.energy;
diagnostics.physical_energy_before_polish = mainState.physical_energy;
diagnostics.entropy_value_before_polish = mainState.entropy_value;
diagnostics.augmented_energy_before_polish = mainState.augmented_energy;
diagnostics.pg_before_polish = mainState.pg_residual;
diagnostics.kkt_before_polish = mainState.kkt_residual;
diagnostics.polish_mode = solver.polish_mode;
diagnostics.polish_attempted = polishResult.polish_attempted;
diagnostics.polish_converged = polishResult.polish_converged;
diagnostics.polish_failed = polishResult.failed;
diagnostics.polish_failure_message = polishResult.failure_message;
diagnostics.polish_status = polishResult.status;
diagnostics.polish_iterations = polishResult.iterations;
diagnostics.polish_elapsed_time = polishResult.elapsed_time;
diagnostics.energy_after_polish = finalState.energy;
diagnostics.physical_energy_after_polish = finalState.physical_energy;
diagnostics.entropy_value_after_polish = finalState.entropy_value;
diagnostics.augmented_energy_after_polish = finalState.augmented_energy;
diagnostics.pg_after_polish = finalState.pg_residual;
diagnostics.kkt_after_polish = finalState.kkt_residual;
diagnostics.polish_energy_change = finalState.energy - mainState.energy;
diagnostics.polish_state_change = sqrt(problem.grid.h ...
    * sum((rhoFinal - rhoMain) .^ 2));
diagnostics.energy = finalState.energy;
diagnostics.physical_energy = finalState.physical_energy;
diagnostics.entropy_value = finalState.entropy_value;
diagnostics.augmented_energy = finalState.augmented_energy;
diagnostics.entropy_enabled = entropyActive;
diagnostics.entropy_eta = problem.entropy.eta;
diagnostics.pg_residual = finalState.pg_residual;
diagnostics.kkt_residual = finalState.kkt_residual;
diagnostics.mass_error = finalState.mass_error;
diagnostics.min_density = finalState.min_density;
diagnostics.total_elapsed_time = mainDiagnostics.elapsed_time ...
    + polishResult.elapsed_time;
diagnostics.total_iterations = mainDiagnostics.iterations ...
    + polishResult.iterations;
if strcmpi(solver.polish_mode, 'none')
    finalTolerance = solver.pg_tol;
else
    finalTolerance = solver.polish.pg_tol;
end
diagnostics.converged = finalState.pg_residual <= finalTolerance;

result.rho = rhoFinal;
result.energy = finalState.energy;
result.physical_energy = finalState.physical_energy;
result.entropy_value = finalState.entropy_value;
result.augmented_energy = finalState.augmented_energy;
result.diagnostics = diagnostics;
result.history.main = mainHistory;
result.history.polish = polishResult.history;
result.solver = solver;
result.regularization = regularizationInfo;
result.problem = problem;
result.main_rho = rhoMain;
result.entropy = problem.entropy;

if solver.display
    printSummary(diagnostics);
end
end

function solver = applySolverDefaults(solver)
if nargin < 1 || isempty(solver)
    solver = struct();
end

defaults.name = 'spg';
defaults.projection_name = 'simplex';
defaults.projection_tol = 1e-13;
defaults.residual_step = 1;
defaults.active_tol = 1e-12;
defaults.L0 = 1;
defaults.backtrack_factor = 2;
defaults.ista_L_decrease = 0.5;
defaults.max_backtracks = 100;
defaults.pg_tol = 1e-8;
defaults.energy_tol = 1e-14;
defaults.max_iter = 200000;
defaults.a = 4;
defaults.feasibility_tol = 1e-13;
defaults.display = true;
defaults.display_interval = 100;
defaults.spg_bb_type = 'bb1';
defaults.spg_alpha_min = 1e-12;
defaults.spg_alpha_max = 1e12;
defaults.spg_alpha_reset = 1;
defaults.spg_curvature_tol = 1e-18;
defaults.spg_nonmonotone_M = 10;
defaults.spg_c1 = 1e-4;
defaults.spg_backtrack = 0.5;
defaults.spg_min_lambda = 1e-14;
defaults.spg_descent_tol = 1e-13;
defaults.polish_mode = 'if_needed';

names = fieldnames(defaults);
for j = 1:numel(names)
    if ~isfield(solver, names{j}) || isempty(solver.(names{j}))
        solver.(names{j}) = defaults.(names{j});
    end
end
if ~isfield(solver, 'polish') || isempty(solver.polish)
    solver.polish = struct();
end
polishDefaults.entry_pg_tol = 1e-5;
polishDefaults.pg_tol = 1e-12;
polishDefaults.max_iter = 50;
polishDefaults.tau_active = 1;
polishDefaults.active_tol = 1e-12;
polishDefaults.gmres_tol = 1e-10;
polishDefaults.gmres_maxit = 200;
polishDefaults.gmres_failure_tol = 0.5;
polishDefaults.residual_c1 = 1e-4;
polishDefaults.backtrack = 0.5;
polishDefaults.min_step = 1e-12;
polishDefaults.max_backtracks = 30;
polishDefaults.mass_tol = 1e-10;
polishDefaults.roundoff_tol = 1e-13;
names = fieldnames(polishDefaults);
for j = 1:numel(names)
    if ~isfield(solver.polish, names{j}) || isempty(solver.polish.(names{j}))
        solver.polish.(names{j}) = polishDefaults.(names{j});
    end
end

if ~ismember(lower(char(solver.projection_name)), {'simplex', 'semismooth'})
    error('src:SolveGroundState1D:UnknownProjection', ...
        'projection_name must be simplex or semismooth.');
end
if ~ismember(lower(char(solver.spg_bb_type)), {'bb1', 'bb2', 'alternate'})
    error('src:SolveGroundState1D:UnknownBBType', ...
        'spg_bb_type must be bb1, bb2, or alternate.');
end
if solver.L0 <= 0 || solver.backtrack_factor <= 1 ...
        || solver.ista_L_decrease <= 0 || solver.ista_L_decrease > 1 ...
        || solver.max_iter < 1 || solver.pg_tol <= 0 || solver.a <= 2 ...
        || solver.residual_step <= 0 || solver.spg_alpha_min <= 0 ...
        || solver.spg_alpha_max < solver.spg_alpha_min ...
        || ~isfinite(solver.spg_alpha_reset) || solver.spg_alpha_reset <= 0 ...
        || solver.spg_nonmonotone_M < 1 ...
        || solver.spg_nonmonotone_M ~= round(solver.spg_nonmonotone_M) ...
        || solver.spg_c1 <= 0 || solver.spg_c1 >= 1 ...
        || solver.spg_min_lambda <= 0 ...
        || solver.spg_backtrack <= 0 || solver.spg_backtrack >= 1
    error('src:SolveGroundState1D:InvalidSolverOptions', ...
        'Invalid solver tolerances, residual step, or line-search parameters.');
end
end

function problem = applyEntropyDefaults(problem)
if ~isfield(problem, 'entropy') || isempty(problem.entropy)
    problem.entropy = struct();
end
defaults.enabled = false;
defaults.eta = 0;
names = fieldnames(defaults);
for j = 1:numel(names)
    if ~isfield(problem.entropy, names{j}) ...
            || isempty(problem.entropy.(names{j}))
        problem.entropy.(names{j}) = defaults.(names{j});
    end
end
if ~islogical(problem.entropy.enabled) && ...
        ~(isnumeric(problem.entropy.enabled) && isscalar(problem.entropy.enabled))
    error('src:SolveGroundState1D:InvalidEntropyEnabled', ...
        'entropy.enabled must be a logical scalar.');
end
if ~isscalar(problem.entropy.eta) || ~isfinite(problem.entropy.eta) ...
        || problem.entropy.eta < 0
    error('src:SolveGroundState1D:InvalidEntropyEta', ...
        'entropy.eta must be a finite nonnegative scalar.');
end
if ~isfield(problem.entropy, 'prox') || isempty(problem.entropy.prox)
    problem.entropy.prox = struct();
end
proxDefaults.mass_tol = 1e-14;
proxDefaults.lambda_max_iter = 50;
proxDefaults.inner_newton_max_iter = 30;
proxDefaults.inner_tol = 1e-14;
names = fieldnames(proxDefaults);
for j = 1:numel(names)
    if ~isfield(problem.entropy.prox, names{j}) ...
            || isempty(problem.entropy.prox.(names{j}))
        problem.entropy.prox.(names{j}) = proxDefaults.(names{j});
    end
end
end

function rho = projectInitial(rho0, problem, solver)
if numel(rho0) ~= problem.grid.N || any(~isfinite(rho0(:)))
    error('src:SolveGroundState1D:InvalidInitialDensity', ...
        'Initial density must be finite and have grid.N entries.');
end
switch lower(char(solver.projection_name))
    case 'simplex'
        rho = src.constraints.ProjectSimplex( ...
            rho0, problem.mass, problem.grid.h);
    case 'semismooth'
        rho = src.constraints.ProjectPositiveConservative( ...
            rho0, problem.mass, problem.grid.h, solver.projection_tol);
end
end

function polish = emptyPolishResult(rho, state, requestedTolerance)
polish.rho = rho;
polish.energy = state.energy;
polish.history = struct();
polish.polish_attempted = false;
polish.polish_converged = state.pg_residual <= requestedTolerance;
polish.failed = false;
polish.failure_message = '';
polish.iterations = 0;
polish.elapsed_time = 0;
polish.status = 'not_attempted';
end

function printMainHeader(solver)
if ~solver.display
    return;
end
if strcmpi(solver.name, 'spg')
    fprintf('   iter   energy             pg_res       dE          alphaBB     lambda      bt\n');
else
    fprintf('   iter   energy             pg_res       dE          L           restart\n');
end
end

function printSummary(diagnostics)
fprintf('\nMain solver : %s\n', diagnostics.main_solver);
fprintf('Main iter   : %d\n', diagnostics.main_iterations);
fprintf('Physical E  : %.15e\n', diagnostics.physical_energy);
fprintf('Entropy H   : %.15e\n', diagnostics.entropy_value);
fprintf('Augmented E : %.15e\n', diagnostics.augmented_energy);
fprintf('PG before   : %.3e\n', diagnostics.pg_before_polish);
if diagnostics.entropy_enabled
    polishName = 'Entropy Newton';
else
    polishName = 'PDAS';
end
fprintf('Polish      : %s (%s)\n', polishName, ...
    onOff(diagnostics.polish_attempted));
fprintf('Polish iter : %d\n', diagnostics.polish_iterations);
fprintf('PG final    : %.3e\n', diagnostics.pg_residual);
fprintf('KKT final   : %.3e\n', diagnostics.kkt_residual);
fprintf('Mass error  : %.3e\n', diagnostics.mass_error);
fprintf('Min density : %.3e\n', diagnostics.min_density);
end

function value = onOff(tf)
if tf
    value = 'used';
else
    value = 'not used';
end
end
