function [modes, coefficients] = FourierCoefficients(u)
%FOURIERCOEFFICIENTS Return fftshifted coefficients c_k = fft(u)_k/N.

u = u(:);
N = numel(u);
if mod(N, 2) ~= 0
    error('src:discretization:ps:FourierCoefficients:InvalidN', ...
        'The number of samples must be even.');
end
modes = (-N/2:N/2-1)';
coefficients = fftshift(fft(u) / N);
end
