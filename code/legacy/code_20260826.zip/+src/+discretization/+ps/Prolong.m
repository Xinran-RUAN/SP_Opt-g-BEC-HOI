function rhoFine = Prolong(rhoCoarse, Nfine)
%PROLONG Fourier zero-padding interpolation to a finer even grid.
%
% Coefficients use c_k = fft(rho)_k/N. For an even coarse grid the real
% Nyquist coefficient is split equally between the +/- Nyquist modes on
% the fine grid. This gives the real trigonometric interpolant.

wasRow = isrow(rhoCoarse);
rhoCoarse = rhoCoarse(:);
N = numel(rhoCoarse);
if mod(N, 2) ~= 0 || ~isscalar(Nfine) || Nfine ~= round(Nfine) || ...
        mod(Nfine, 2) ~= 0 || Nfine < N
    error('src:discretization:ps:Prolong:InvalidSize', ...
        'Coarse and fine sizes must be even integers with Nfine >= N.');
end
if Nfine == N
    rhoFine = rhoCoarse;
else
    c = fft(rhoCoarse) / N;
    cFine = complex(zeros(Nfine, 1));
    cFine(1:N/2) = c(1:N/2);
    cFine(Nfine-N/2+2:Nfine) = c(N/2+2:N);
    nyquist = c(N/2+1);
    cFine(N/2+1) = nyquist / 2;
    cFine(Nfine-N/2+1) = nyquist / 2;
    rhoFine = real(ifft(Nfine * cFine));
end
if wasRow
    rhoFine = rhoFine.';
end
end
