function gradient = Gradient(rho, problem)
%GRADIENT Variational gradient under <u,v>_h = h*sum(u.*v).
%
% No outer factor h appears in this vector. Energy and gradient share the
% same denominator implementation through EvaluateDenominator.

rho = rho(:);
q = src.discretization.ps.FirstDerivative(rho, problem.plan);
[s, ds] = src.regularization.EvaluateDenominator( ...
    rho, problem.regularization);
dtQOverS = src.discretization.ps.AdjointFirstDerivative(q ./ s, problem.plan);
dtQ = src.discretization.ps.AdjointFirstDerivative(q, problem.plan);

gradient = 0.25 * dtQOverS ...
    - 0.125 * (q .^ 2) .* ds ./ (s .^ 2) ...
    + problem.V(:) + problem.beta * rho + problem.delta * dtQ;
end
