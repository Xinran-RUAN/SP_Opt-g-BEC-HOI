function [energy, parts] = Energy(rho, problem)
%ENERGY Discrete regularized 1D HOI density energy.

rho = rho(:);
q = src.discretization.ps.FirstDerivative(rho, problem.plan);
[s, ~, ~] = src.regularization.EvaluateDenominator( ...
    rho, problem.regularization);

parts.kinetic = problem.grid.h * sum(q .^ 2 ./ (8 * s));
parts.potential = problem.grid.h * sum(problem.V(:) .* rho);
parts.beta = problem.grid.h * (problem.beta / 2) * sum(rho .^ 2);
parts.delta = problem.grid.h * (problem.delta / 2) * sum(q .^ 2);
energy = parts.kinetic + parts.potential + parts.beta + parts.delta;
end
