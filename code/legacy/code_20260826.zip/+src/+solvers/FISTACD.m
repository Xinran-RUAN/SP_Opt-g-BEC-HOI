function [rho, diagnostics, history] = FISTACD(problem, rho0, solver)
%FISTACD Optional accelerated comparison method with robust restarts.
%
% Feasibility and monotone restarts alter the standard accelerated method;
% this implementation does not claim all unrestarted FISTA rate theory.

startTime = tic;
rho = rho0(:);
rhoPrevious = rho;
energy = src.discretization.ps.Energy(rho, problem);
gradient = src.discretization.ps.Gradient(rho, problem);
state = src.solvers.EvaluateState(rho, problem, solver, energy, gradient);
objective = state.augmented_energy;
L = solver.L0;
history = allocateHistory(solver.max_iter);
converged = state.pg_residual <= solver.pg_tol;
restartCount = 0;
relativeEnergyChange = NaN;
iterationCount = 0;

for iteration = 1:solver.max_iter
    if converged
        break;
    end
    alpha = (iteration - 1) / (iteration + solver.a);
    extrapolated = rho + alpha * (rho - rhoPrevious);
    restarted = false;

    if any(extrapolated < -solver.feasibility_tol)
        extrapolated = rho;
        restarted = true;
    elseif any(extrapolated < 0)
        extrapolated = projectFeasible(max(extrapolated, 0), problem, solver);
    end

    energyY = src.discretization.ps.Energy(extrapolated, problem);
    gradientY = src.discretization.ps.Gradient(extrapolated, problem);
    [candidate, candidateEnergy, L] = backtrackingStep( ...
        extrapolated, energyY, gradientY, L, problem, solver);

    candidateEntropy = entropyValue(candidate, problem);
    candidateObjective = candidateEnergy + entropyEta(problem) * candidateEntropy;
    monotoneTolerance = 100 * eps(max([1, abs(objective), abs(candidateObjective)]));
    if candidateObjective > objective + monotoneTolerance
        extrapolated = rho;
        energyY = energy;
        gradientY = gradient;
        [candidate, candidateEnergy, L] = backtrackingStep( ...
            extrapolated, energyY, gradientY, L, problem, solver);
        candidateEntropy = entropyValue(candidate, problem);
        candidateObjective = candidateEnergy ...
            + entropyEta(problem) * candidateEntropy;
        restarted = true;
    end

    candidateGradient = src.discretization.ps.Gradient(candidate, problem);
    candidateState = src.solvers.EvaluateState( ...
        candidate, problem, solver, candidateEnergy, candidateGradient);
    relativeEnergyChange = abs(candidateObjective - objective) ...
        / max(1, abs(objective));
    if restarted
        restartCount = restartCount + 1;
    end

    iterationCount = iteration;
    history.iteration(iteration) = iteration;
    history.elapsed_time(iteration) = toc(startTime);
    history.energy(iteration) = candidateEnergy;
    history.physical_energy(iteration) = candidateEnergy;
    history.entropy_value(iteration) = candidateEntropy;
    history.augmented_energy(iteration) = candidateObjective;
    history.pg_residual(iteration) = candidateState.pg_residual;
    history.relative_energy_change(iteration) = relativeEnergyChange;
    history.mass_error(iteration) = candidateState.mass_error;
    history.min_density(iteration) = candidateState.min_density;
    history.accepted_L(iteration) = L;
    history.restart(iteration) = restarted;

    oldRho = rho;
    rho = candidate;
    energy = candidateEnergy;
    objective = candidateObjective;
    gradient = candidateGradient;
    state = candidateState;
    if restarted
        rhoPrevious = rho;
    else
        rhoPrevious = oldRho;
    end

    if solver.display && (iteration == 1 || mod(iteration, solver.display_interval) == 0)
        fprintf('%7d  %.15e  %.3e  %.3e  %.3e  %d\n', ...
            iteration, energy, state.pg_residual, relativeEnergyChange, L, restarted);
    end
    if state.pg_residual <= solver.pg_tol
        converged = true;
    end
end

history = trimHistory(history, iterationCount);
diagnostics.iterations = iterationCount;
diagnostics.energy = energy;
diagnostics.physical_energy = state.physical_energy;
diagnostics.entropy_value = state.entropy_value;
diagnostics.augmented_energy = state.augmented_energy;
diagnostics.pg_residual = state.pg_residual;
diagnostics.kkt_residual = state.kkt_residual;
diagnostics.relative_energy_change = relativeEnergyChange;
diagnostics.mass_error = state.mass_error;
diagnostics.min_density = state.min_density;
diagnostics.accepted_L = L;
diagnostics.converged = converged;
diagnostics.failed = false;
diagnostics.failure_message = '';
diagnostics.restarts = restartCount;
diagnostics.elapsed_time = toc(startTime);
diagnostics.energy_plateau = relativeEnergyChange <= solver.energy_tol;
end

function rho = projectFeasible(z, problem, solver)
switch lower(char(solver.projection_name))
    case 'simplex'
        rho = src.constraints.ProjectSimplex(z, problem.mass, problem.grid.h);
    case 'semismooth'
        rho = src.constraints.ProjectPositiveConservative( ...
            z, problem.mass, problem.grid.h, solver.projection_tol);
end
end

function [candidate, candidateEnergy, acceptedL] = backtrackingStep( ...
    y, energyY, gradientY, initialL, problem, solver)
acceptedL = initialL;
for trial = 1:solver.max_backtracks
    candidate = src.solvers.ProxStep( ...
        y, gradientY, acceptedL, problem, solver);
    candidateEnergy = src.discretization.ps.Energy(candidate, problem);
    difference = candidate - y;
    majorant = energyY ...
        + problem.grid.h * sum(gradientY .* difference) ...
        + 0.5 * acceptedL * problem.grid.h * sum(difference .^ 2);
    roundoff = 100 * eps(max([1, abs(energyY), abs(candidateEnergy)]));
    if candidateEnergy <= majorant + roundoff
        return;
    end
    acceptedL = solver.backtrack_factor * acceptedL;
    if ~isfinite(acceptedL)
        break;
    end
end
error('src:solvers:FISTACD:BacktrackingFailure', ...
    'Backtracking failed to establish the h-inner-product majorization.');
end

function history = allocateHistory(maxIter)
fields = {'iteration', 'elapsed_time', 'energy', 'physical_energy', ...
    'entropy_value', 'augmented_energy', 'pg_residual', ...
    'relative_energy_change', 'mass_error', 'min_density', 'accepted_L'};
for j = 1:numel(fields)
    history.(fields{j}) = nan(maxIter, 1);
end
history.restart = false(maxIter, 1);
end

function history = trimHistory(history, count)
fields = fieldnames(history);
for j = 1:numel(fields)
    history.(fields{j}) = history.(fields{j})(1:count, :);
end
end

function eta = entropyEta(problem)
eta = 0;
if isfield(problem, 'entropy') && isfield(problem.entropy, 'enabled') ...
        && problem.entropy.enabled && isfield(problem.entropy, 'eta') ...
        && problem.entropy.eta > 0
    eta = problem.entropy.eta;
end
end

function value = entropyValue(rho, problem)
value = src.entropy.Value(rho, problem.grid);
end
