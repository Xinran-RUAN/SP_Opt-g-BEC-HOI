function [residual, mapping, projected] = ProjectedGradientResidual( ...
    rho, gradient, problem, solver)
%PROJECTEDGRADIENTRESIDUAL Unified fixed-step stationarity residual.
%
% Every first-order solver and the PDAS polish use the same residual step,
% tau_r = solver.residual_step, so their reported residuals are comparable.

tau = solver.residual_step;
if ~isscalar(tau) || ~isfinite(tau) || tau <= 0
    error('src:solvers:ProjectedGradientResidual:InvalidStep', ...
        'solver.residual_step must be positive and finite.');
end
projected = src.solvers.ApplyProx( ...
    rho(:) - tau * gradient(:), tau, problem, solver);
mapping = (rho(:) - projected(:)) / tau;
residual = sqrt(problem.grid.h * sum(mapping .^ 2));
end
