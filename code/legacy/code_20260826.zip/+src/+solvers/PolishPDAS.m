function result = PolishPDAS(rho0, problem, options)
%POLISHPDAS Matrix-free primal-dual active-set/semismooth Newton polish.
%
% The routine is intended only for a feasible state already inside the
% local high-accuracy region. It globalizes Newton steps using the unified
% projected-gradient residual, not strict energy decrease.

options = applyDefaults(options);
startTime = tic;
rho = rho0(:);
energy = src.discretization.ps.Energy(rho, problem);
gradient = src.discretization.ps.Gradient(rho, problem);
state = src.solvers.EvaluateState(rho, problem, options, energy, gradient);
initialState = state;
history = allocateHistory(options.max_iter);
converged = state.pg_residual <= options.pg_tol;
attempted = false;
failed = false;
failureMessage = '';
iterationCount = 0;
previousFree = [];

if state.pg_residual > options.entry_pg_tol
    failureMessage = sprintf( ...
        'PDAS entry rejected: PG residual %.3e exceeds entry tolerance %.3e.', ...
        state.pg_residual, options.entry_pg_tol);
    result = packageResult();
    return;
end

attempted = true;
for iteration = 1:options.max_iter
    if converged
        break;
    end

    projected = src.constraints.ProjectSimplex( ...
        rho - options.tau_active * gradient, problem.mass, problem.grid.h);
    free = projected > options.active_tol;
    if ~any(free)
        [~, freeIndex] = max(projected);
        free(freeIndex) = true;
    end
    active = ~free;
    activeSetChanges = 0;
    if ~isempty(previousFree)
        activeSetChanges = nnz(xor(free, previousFree));
    end
    previousFree = free;

    lambda = -mean(gradient(free));
    activeCorrection = zeros(problem.grid.N, 1);
    activeCorrection(active) = -rho(active);
    hessianActive = src.solvers.HessianAction( ...
        rho, activeCorrection, problem, problem.plan, problem.regularization);
    massResidual = src.constraints.Mass(rho, problem.grid.h) - problem.mass;
    rightHandSide = [ ...
        -(gradient(free) + lambda + hessianActive(free)); ...
        -massResidual - problem.grid.h * sum(activeCorrection(active))];

    operator = @(z) kktAction(z, free, rho, problem);
    numberOfUnknowns = nnz(free) + 1;
    restart = min(50, numberOfUnknowns);
    maxOuter = min(numberOfUnknowns, ...
        max(1, ceil(options.gmres_maxit / restart)));
    [z, gmresFlag, gmresRelativeResidual, gmresIteration] = gmres( ...
        operator, rightHandSide, restart, options.gmres_tol, maxOuter);
    if gmresIteration(1) == 0
        gmresIterations = gmresIteration(2);
    else
        gmresIterations = (gmresIteration(1) - 1) * restart ...
            + gmresIteration(2);
    end
    % An inexact Newton correction is still useful when the KKT system is
    % ill-conditioned, provided GMRES reduced its residual substantially.
    % Globalization below decides whether that correction is acceptable.
    if gmresFlag ~= 0 && gmresRelativeResidual > options.gmres_failure_tol
        failed = true;
        failureMessage = sprintf( ...
            'PDAS GMRES failed: flag=%d, relative residual=%.3e.', ...
            gmresFlag, gmresRelativeResidual);
        break;
    end

    correction = activeCorrection;
    correction(free) = z(1:end-1);
    negativeDirection = correction < 0;
    if any(negativeDirection)
        maximumPositiveStep = min(-rho(negativeDirection) ...
            ./ correction(negativeDirection));
    else
        maximumPositiveStep = inf;
    end
    step = min(1, 0.99 * maximumPositiveStep);
    accepted = false;
    backtracks = 0;
    trialState = state;
    trialRho = rho;

    while step >= options.min_step && backtracks <= options.max_backtracks
        trialRho = rho + step * correction;
        trialMassError = abs(src.constraints.Mass( ...
            trialRho, problem.grid.h) - problem.mass);
        if min(trialRho) >= -options.roundoff_tol ...
                && trialMassError <= options.mass_tol
            trialEnergy = src.discretization.ps.Energy(trialRho, problem);
            trialGradient = src.discretization.ps.Gradient(trialRho, problem);
            trialState = src.solvers.EvaluateState( ...
                trialRho, problem, options, trialEnergy, trialGradient);
            residualBound = (1 - options.residual_c1 * step) ...
                * state.pg_residual;
            if trialState.pg_residual <= residualBound ...
                    || trialState.pg_residual <= options.pg_tol
                accepted = true;
                break;
            end
        end
        step = options.backtrack * step;
        backtracks = backtracks + 1;
    end

    if ~accepted
        failed = true;
        failureMessage = 'PDAS residual globalization failed.';
        break;
    end

    rho = trialRho;
    energy = trialState.energy;
    gradient = trialState.gradient;
    state = trialState;
    iterationCount = iteration;
    history.iteration(iteration) = iteration;
    history.elapsed_time(iteration) = toc(startTime);
    history.energy(iteration) = energy;
    history.pg_residual(iteration) = state.pg_residual;
    history.kkt_residual(iteration) = state.kkt_residual;
    history.mass_error(iteration) = state.mass_error;
    history.min_density(iteration) = state.min_density;
    history.active_count(iteration) = nnz(active);
    history.free_count(iteration) = nnz(free);
    history.active_set_changes(iteration) = activeSetChanges;
    history.gmres_iterations(iteration) = gmresIterations;
    history.gmres_flag(iteration) = gmresFlag;
    history.gmres_relative_residual(iteration) = gmresRelativeResidual;
    history.step(iteration) = step;
    history.backtracks(iteration) = backtracks;

    if options.display
        fprintf('PDAS %3d  %.3e  %.3e  %5d  %4d  %.3e\n', ...
            iteration, state.pg_residual, state.kkt_residual, nnz(active), ...
            gmresIterations, step);
    end
    if state.pg_residual <= options.pg_tol
        converged = true;
    end
end

result = packageResult();

    function output = packageResult()
        output.rho = rho;
        output.energy = energy;
        output.history = trimHistory(history, iterationCount);
        output.polish_attempted = attempted;
        output.polish_converged = converged;
        output.failed = failed;
        output.failure_message = failureMessage;
        if converged
            output.status = 'converged';
        elseif failed
            output.status = 'failed';
        elseif attempted
            output.status = 'max_iterations';
        else
            output.status = 'entry_rejected';
        end
        output.iterations = iterationCount;
        output.elapsed_time = toc(startTime);
        output.pg_residual_before = initialState.pg_residual;
        output.pg_residual = state.pg_residual;
        output.kkt_residual = state.kkt_residual;
        output.mass_error = state.mass_error;
        output.min_density = state.min_density;
        output.active_count = state.kkt.active_count;
        output.free_count = state.kkt.free_count;
        output.energy_change = energy - initialState.energy;
        output.state_change = sqrt(problem.grid.h ...
            * sum((rho - rho0(:)) .^ 2));
    end
end

function value = kktAction(z, free, rho, problem)
numberOfFree = nnz(free);
direction = zeros(size(rho));
direction(free) = z(1:numberOfFree);
hessianDirection = src.solvers.HessianAction( ...
    rho, direction, problem, problem.plan, problem.regularization);
value = [hessianDirection(free) + z(end); ...
    problem.grid.h * sum(direction(free))];
end

function options = applyDefaults(options)
if nargin < 1 || isempty(options)
    options = struct();
end
defaults.entry_pg_tol = 1e-5;
defaults.pg_tol = 1e-12;
defaults.max_iter = 50;
defaults.tau_active = 1;
defaults.active_tol = 1e-12;
defaults.gmres_tol = 1e-10;
defaults.gmres_maxit = 200;
defaults.gmres_failure_tol = 0.5;
defaults.residual_step = 1;
defaults.projection_name = 'simplex';
defaults.projection_tol = 1e-13;
defaults.residual_c1 = 1e-4;
defaults.backtrack = 0.5;
defaults.min_step = 1e-12;
defaults.max_backtracks = 30;
defaults.mass_tol = 1e-10;
defaults.roundoff_tol = 1e-13;
defaults.display = true;
names = fieldnames(defaults);
for j = 1:numel(names)
    if ~isfield(options, names{j}) || isempty(options.(names{j}))
        options.(names{j}) = defaults.(names{j});
    end
end
end

function history = allocateHistory(maxIter)
fields = {'iteration', 'elapsed_time', 'energy', 'pg_residual', ...
    'kkt_residual', 'mass_error', 'min_density', 'active_count', ...
    'free_count', 'active_set_changes', 'gmres_iterations', 'gmres_flag', ...
    'gmres_relative_residual', 'step', 'backtracks'};
for j = 1:numel(fields)
    history.(fields{j}) = nan(maxIter, 1);
end
end

function history = trimHistory(history, count)
fields = fieldnames(history);
for j = 1:numel(fields)
    history.(fields{j}) = history.(fields{j})(1:count, :);
end
end
