function hessianEta = HessianAction(rho, eta, modelData, plan, reg)
%HESSIANACTION Matrix-free action of the discrete variational Hessian.
%
% For piecewise_c1, d2s is the selected one-sided/generalized second
% derivative supplied by EvaluateDenominator. It is used by the
% semismooth polish and is not a claim of classical C2 regularity.

rho = rho(:);
eta = eta(:);
if numel(rho) ~= plan.N || numel(eta) ~= plan.N
    error('src:solvers:HessianAction:SizeMismatch', ...
        'rho and eta must have plan.N entries.');
end
q = src.discretization.ps.FirstDerivative(rho, plan);
dq = src.discretization.ps.FirstDerivative(eta, plan);
[s, ds, d2s] = src.regularization.EvaluateDenominator(rho, reg);

insideAdjoint = dq ./ s - q .* ds .* eta ./ (s .^ 2);
firstTerm = 0.25 * src.discretization.ps.AdjointFirstDerivative( ...
    insideAdjoint, plan);
denominatorDerivative = d2s ./ (s .^ 2) ...
    - 2 * (ds .^ 2) ./ (s .^ 3);
secondTerm = -0.125 * ( ...
    2 * q .* dq .* ds ./ (s .^ 2) ...
    + (q .^ 2) .* denominatorDerivative .* eta);
dtDeta = src.discretization.ps.AdjointFirstDerivative(dq, plan);
hessianEta = firstTerm + secondTerm ...
    + modelData.beta * eta + modelData.delta * dtDeta;
end
