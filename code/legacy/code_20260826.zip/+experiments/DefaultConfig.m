function config = DefaultConfig()
%DEFAULTCONFIG Default configuration for one reliable 1D HOI solve.

config.parameters = model.DefaultParameters1D();
config.regularization.name = 'shift_smooth';
config.regularization.epsilon = config.parameters.epsilon;
config.regularization.transition_width = config.parameters.epsilon;

config.entropy.enabled = false;
config.entropy.eta = 0;
config.entropy.prox.mass_tol = 1e-14;
config.entropy.prox.lambda_max_iter = 50;
config.entropy.prox.inner_newton_max_iter = 30;
config.entropy.prox.inner_tol = 1e-14;

config.solver.name = 'spg';
config.solver.projection_name = 'simplex';
config.solver.projection_tol = 1e-13;
config.solver.residual_step = 1;
config.solver.active_tol = 1e-12;
config.solver.L0 = 1;
config.solver.backtrack_factor = 2;
config.solver.ista_L_decrease = 0.5;
config.solver.max_backtracks = 100;
config.solver.pg_tol = 1e-8;
config.solver.energy_tol = 1e-14;
config.solver.max_iter = 200000;
config.solver.a = 4;
config.solver.feasibility_tol = 1e-13;
config.solver.display = true;
config.solver.display_interval = 100;
config.solver.spg_bb_type = 'bb1';
config.solver.spg_alpha_min = 1e-12;
config.solver.spg_alpha_max = 1e12;
config.solver.spg_alpha_reset = 1;
config.solver.spg_curvature_tol = 1e-18;
config.solver.spg_nonmonotone_M = 10;
config.solver.spg_c1 = 1e-4;
config.solver.spg_backtrack = 0.5;
config.solver.spg_min_lambda = 1e-14;
config.solver.spg_descent_tol = 1e-13;
config.solver.polish_mode = 'if_needed';
config.solver.polish.entry_pg_tol = 1e-5;
config.solver.polish.pg_tol = 1e-12;
config.solver.polish.max_iter = 50;
config.solver.polish.tau_active = 1;
config.solver.polish.active_tol = 1e-12;
config.solver.polish.gmres_tol = 1e-10;
config.solver.polish.gmres_maxit = 200;
config.solver.polish.gmres_failure_tol = 0.5;
config.solver.polish.residual_c1 = 1e-4;
config.solver.polish.backtrack = 0.5;
config.solver.polish.min_step = 1e-12;
config.solver.polish.max_backtracks = 30;
config.solver.polish.mass_tol = 1e-10;
config.solver.polish.roundoff_tol = 1e-13;

config.output.show_plot = true;
config.output.save_result = true;
config.output.overwrite_existing = false;
end
