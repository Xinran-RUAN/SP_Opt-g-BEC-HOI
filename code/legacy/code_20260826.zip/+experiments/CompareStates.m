function comparison = CompareStates(rhoCoarse, rhoReference, referenceGrid)
%COMPARESTATES Compare densities only after spectral transfer to one grid.

rhoOnReference = src.discretization.ps.Prolong( ...
    rhoCoarse, referenceGrid.N);
difference = rhoOnReference(:) - rhoReference(:);
comparison.density_L2_error = sqrt(referenceGrid.h * sum(difference .^ 2));
comparison.density_Linf_error = max(abs(difference));
comparison.rho_on_reference = rhoOnReference;
end
