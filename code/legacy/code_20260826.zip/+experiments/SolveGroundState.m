function result = SolveGroundState(config, rho0)
%SOLVEGROUNDSTATE Assemble and solve one configured discrete problem.

parameters = config.parameters;
grid = model.SetupGrid1D(parameters);
plan = src.discretization.ps.Plan1D(grid);
V = model.BuildPotential(grid, parameters.potential_label);

regularization = config.regularization;
regularization.epsilon = parameters.epsilon;
[regularization, regularizationInfo] = ...
    src.regularization.Validate(regularization);

problem.grid = grid;
problem.plan = plan;
problem.V = V;
problem.beta = parameters.beta;
problem.delta = parameters.delta;
problem.mass = parameters.mass;
problem.regularization = regularization;
if isfield(config, 'entropy')
    problem.entropy = config.entropy;
else
    problem.entropy.enabled = false;
    problem.entropy.eta = 0;
end
entropyActive = problem.entropy.enabled && problem.entropy.eta > 0;
if entropyActive && strcmpi(config.solver.name, 'spg')
    config.solver.name = 'fista_cd';
end

if nargin < 2 || isempty(rho0)
    rho0 = model.InitialDensity( ...
        grid, parameters.mass, config.solver.projection_name);
end

result = src.SolveGroundState1D(problem, rho0, config.solver);
result.parameters = parameters;
result.regularization = regularizationInfo;
result.grid = grid;
result.potential = V;

tailWidth = min(2, 0.1 * grid.L);
tailMask = abs(grid.x) >= grid.L - tailWidth;
tailMass = grid.h * sum(result.rho(tailMask));
tailMax = max(result.rho(tailMask));
result.diagnostics.tail_width = tailWidth;
result.diagnostics.tail_mass = tailMass;
result.diagnostics.tail_max = tailMax;
result.diagnostics.tail_indicator = max(tailMass, tailMax);
result.diagnostics.rho_left_boundary = result.rho(1);
result.diagnostics.rho_right_boundary = result.rho(end);
result.diagnostics.boundary_value_mismatch = ...
    abs(result.rho(1) - result.rho(end));
derivative = src.discretization.ps.FirstDerivative(result.rho, problem.plan);
result.diagnostics.boundary_derivative_mismatch = ...
    abs(derivative(1) - derivative(end));
result.diagnostics.active_set = ...
    src.diagnostics.ActiveSetDiagnostics(result.rho, grid);
result.diagnostics.fourier_tail = ...
    src.diagnostics.FourierTailDiagnostics(result.rho);
end
