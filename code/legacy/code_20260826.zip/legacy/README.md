# Legacy reference

The original scripts and their `Data/` and `Figure/` directories remain
unchanged in `../../Code-DensityFormulation/`. They are retained only as a
reference; active runs use the package API in this project.
