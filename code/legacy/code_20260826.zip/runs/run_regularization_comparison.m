%RUN_REGULARIZATION_COMPARISON Fixed-grid epsilon study, separate from mesh error.
clearvars; clc;

% -------------------------- editable settings --------------------------
regularization_names = {
    'shift_smooth'
    'piecewise_c1'
    'piecewise_c2'
    'piecewise_c3'
};
epsilon_list = [1e-1; 5e-2; 2e-2; 1e-2; 5e-3; 2e-3; 1e-3];

N = 512;
L = 32;
beta = 10;
delta = 10;

solver_name = 'spg';
projection_name = 'simplex';
pg_tol = 1e-8;
max_iter = 200000;
polish_mode = 'if_needed';
polish_pg_tol = 1e-12;

show_plot = true;
save_result = true;
overwrite_existing = false;
% -----------------------------------------------------------------------

if any(diff(epsilon_list) >= 0)
    error('epsilon_list must be strictly decreasing for warm starts.');
end
root = fileparts(fileparts(mfilename('fullpath')));
addpath(root);
startup_HOI();
config = experiments.DefaultConfig();
config.parameters.beta = beta;
config.parameters.delta = delta;
config.parameters.L = L;
config.parameters.N = N;
config.solver.name = solver_name;
config.solver.projection_name = projection_name;
config.solver.pg_tol = pg_tol;
config.solver.max_iter = max_iter;
config.solver.polish_mode = polish_mode;
config.solver.polish.pg_tol = polish_pg_tol;
config.solver.display = false;

numberOfRegularizations = numel(regularization_names);
numberOfEpsilons = numel(epsilon_list);
rho = cell(numberOfRegularizations, numberOfEpsilons);
energy = nan(numberOfRegularizations, numberOfEpsilons);
history = cell(numberOfRegularizations, numberOfEpsilons);
diagnostics.pg_residual = nan(numberOfRegularizations, numberOfEpsilons);
diagnostics.pg_before_polish = nan(numberOfRegularizations, numberOfEpsilons);
diagnostics.pg_after_polish = nan(numberOfRegularizations, numberOfEpsilons);
diagnostics.kkt_after_polish = nan(numberOfRegularizations, numberOfEpsilons);
diagnostics.polish_iterations = nan(numberOfRegularizations, numberOfEpsilons);
diagnostics.iterations = nan(numberOfRegularizations, numberOfEpsilons);
diagnostics.mass_error = nan(numberOfRegularizations, numberOfEpsilons);
diagnostics.min_density = nan(numberOfRegularizations, numberOfEpsilons);
regularization.names = regularization_names;
regularization.epsilon = epsilon_list;
regularization.info = cell(numberOfRegularizations, numberOfEpsilons);

for regIndex = 1:numberOfRegularizations
    warmStart = [];
    fprintf('\nregularization comparison: %s\n', regularization_names{regIndex});
    for epsilonIndex = 1:numberOfEpsilons
        epsilon = epsilon_list(epsilonIndex);
        config.parameters.epsilon = epsilon;
        config.regularization.name = regularization_names{regIndex};
        config.regularization.epsilon = epsilon;
        config.regularization.transition_width = epsilon;
        discreteResult = experiments.SolveGroundState(config, warmStart);
        warmStart = discreteResult.rho;
        rho{regIndex, epsilonIndex} = discreteResult.rho;
        energy(regIndex, epsilonIndex) = discreteResult.energy;
        history{regIndex, epsilonIndex} = discreteResult.history;
        diagnostics.pg_residual(regIndex, epsilonIndex) = ...
            discreteResult.diagnostics.pg_residual;
        diagnostics.pg_before_polish(regIndex, epsilonIndex) = ...
            discreteResult.diagnostics.pg_before_polish;
        diagnostics.pg_after_polish(regIndex, epsilonIndex) = ...
            discreteResult.diagnostics.pg_after_polish;
        diagnostics.kkt_after_polish(regIndex, epsilonIndex) = ...
            discreteResult.diagnostics.kkt_after_polish;
        diagnostics.polish_iterations(regIndex, epsilonIndex) = ...
            discreteResult.diagnostics.polish_iterations;
        diagnostics.iterations(regIndex, epsilonIndex) = ...
            discreteResult.diagnostics.total_iterations;
        diagnostics.mass_error(regIndex, epsilonIndex) = ...
            discreteResult.diagnostics.mass_error;
        diagnostics.min_density(regIndex, epsilonIndex) = ...
            discreteResult.diagnostics.min_density;
        regularization.info{regIndex, epsilonIndex} = ...
            discreteResult.regularization;
        fprintf('  eps=%.1e  E=%.12e  PG %.3e -> %.3e  main=%d  polish=%d\n', ...
            epsilon, discreteResult.energy, ...
            discreteResult.diagnostics.pg_before_polish, ...
            discreteResult.diagnostics.pg_after_polish, ...
            discreteResult.diagnostics.main_iterations, ...
            discreteResult.diagnostics.polish_iterations);
    end
end

parameters = config.parameters;
parameters.epsilon_list = epsilon_list;
grid = model.SetupGrid1D(parameters);
solver = config.solver;
archive.parameters = parameters;
archive.regularization = regularization;
archive.grid = grid;
archive.solver = solver;
archive.rho = rho;
archive.energy = energy;
archive.diagnostics = diagnostics;
archive.history = history;

if save_result
    baseName = sprintf('regularization_comparison_N%d.mat', N);
    result_file = experiments.SaveResult( ...
        archive, 'regularization', baseName, overwrite_existing);
    if ~isempty(result_file)
        fprintf('saved: %s\n', result_file);
    end
end
if show_plot && save_result && exist('result_file', 'var') && ~isempty(result_file)
    run(fullfile(root, 'post', 'post_regularization_comparison.m'));
end
