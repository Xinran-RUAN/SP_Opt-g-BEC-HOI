%RUN_MESH_REFINEMENT Separate spatial refinement from optimization error.
clearvars; clc;

% -------------------------- editable settings --------------------------
regularization_names = {
    'shift_smooth'
    'piecewise_c1'
    'piecewise_c2'
    'piecewise_c3'
};
epsilon = 1e-3;
transition_width = epsilon;

N_list = [32, 64, 128, 256, 512];
N_ref = 1024;                 % may be changed to 2048
L = 32;
beta = 10;
delta = 10;

solver_name = 'spg';
projection_name = 'simplex';
pg_tol = 1e-7;
max_iter = 200000;
polish_mode = 'if_needed';
polish_pg_tol = 1e-12;

show_plot = true;
save_result = true;
overwrite_existing = false;
% -----------------------------------------------------------------------

if any(mod(N_list, 2) ~= 0) || mod(N_ref, 2) ~= 0 || N_ref <= max(N_list)
    error('N_list and N_ref must be even, with N_ref > max(N_list).');
end

root = fileparts(fileparts(mfilename('fullpath')));
addpath(root);
startup_HOI();
baseConfig = experiments.DefaultConfig();
baseConfig.parameters.beta = beta;
baseConfig.parameters.delta = delta;
baseConfig.parameters.L = L;
baseConfig.parameters.epsilon = epsilon;
baseConfig.solver.name = solver_name;
baseConfig.solver.projection_name = projection_name;
baseConfig.solver.pg_tol = pg_tol;
baseConfig.solver.max_iter = max_iter;
baseConfig.solver.polish_mode = polish_mode;
baseConfig.solver.polish.pg_tol = polish_pg_tol;
baseConfig.solver.display = false;

numberOfRegularizations = numel(regularization_names);
numberOfMeshes = numel(N_list);
rho.solutions = cell(numberOfRegularizations, numberOfMeshes);
rho.reference = cell(numberOfRegularizations, 1);
energy.solutions = nan(numberOfRegularizations, numberOfMeshes);
energy.reference = nan(numberOfRegularizations, 1);
grid.solutions = cell(numberOfRegularizations, numberOfMeshes);
grid.reference = cell(numberOfRegularizations, 1);
history.solutions = cell(numberOfRegularizations, numberOfMeshes);
history.reference = cell(numberOfRegularizations, 1);
diagnostics.records = cell(numberOfRegularizations, 1);
diagnostics.reference = cell(numberOfRegularizations, 1);
diagnostics.fourier_modes = cell(numberOfRegularizations, 1);
diagnostics.fourier_coefficients = cell(numberOfRegularizations, 1);
regularization.names = regularization_names;
regularization.epsilon = epsilon;
regularization.transition_width = transition_width;
regularization.info = cell(numberOfRegularizations, 1);

for regIndex = 1:numberOfRegularizations
    regName = regularization_names{regIndex};
    fprintf('\nmesh refinement: %s\n', regName);
    config = baseConfig;
    config.regularization.name = regName;
    config.regularization.epsilon = epsilon;
    config.regularization.transition_width = transition_width;
    warmStart = [];
    records = repmat(emptyRecord(), numberOfMeshes, 1);

    for meshIndex = 1:numberOfMeshes
        config.parameters.N = N_list(meshIndex);
        fineGrid = model.SetupGrid1D(config.parameters);
        if ~isempty(warmStart)
            warmStart = experiments.TransferState1D( ...
                warmStart, fineGrid, config.parameters.mass);
        end
        discreteResult = experiments.SolveGroundState(config, warmStart);
        warmStart = discreteResult.rho;
        rho.solutions{regIndex, meshIndex} = discreteResult.rho;
        energy.solutions(regIndex, meshIndex) = discreteResult.energy;
        grid.solutions{regIndex, meshIndex} = discreteResult.grid;
        history.solutions{regIndex, meshIndex} = discreteResult.history;
        records(meshIndex) = recordFromResult(discreteResult);
        fprintf(['  N=%4d  E=%.12e  PG %.3e -> %.3e  ' ...
            'tail=%.3e  main=%d  polish=%d\n'], ...
            N_list(meshIndex), discreteResult.energy, ...
            discreteResult.diagnostics.pg_before_polish, ...
            discreteResult.diagnostics.pg_after_polish, ...
            discreteResult.diagnostics.tail_indicator, ...
            discreteResult.diagnostics.main_iterations, ...
            discreteResult.diagnostics.polish_iterations);
    end

    config.parameters.N = N_ref;
    referenceGrid = model.SetupGrid1D(config.parameters);
    warmStart = experiments.TransferState1D( ...
        warmStart, referenceGrid, config.parameters.mass);
    referenceResult = experiments.SolveGroundState(config, warmStart);
    rho.reference{regIndex} = referenceResult.rho;
    energy.reference(regIndex) = referenceResult.energy;
    grid.reference{regIndex} = referenceResult.grid;
    history.reference{regIndex} = referenceResult.history;
    diagnostics.reference{regIndex} = referenceResult.diagnostics;
    regularization.info{regIndex} = referenceResult.regularization;
    [diagnostics.fourier_modes{regIndex}, ...
        diagnostics.fourier_coefficients{regIndex}] = ...
        src.discretization.ps.FourierCoefficients(referenceResult.rho);

    for meshIndex = 1:numberOfMeshes
        comparison = experiments.CompareStates( ...
            rho.solutions{regIndex, meshIndex}, referenceResult.rho, ...
            referenceResult.grid);
        records(meshIndex).energy_error = abs( ...
            energy.solutions(regIndex, meshIndex) - referenceResult.energy);
        records(meshIndex).density_L2_error = comparison.density_L2_error;
        records(meshIndex).density_Linf_error = comparison.density_Linf_error;
    end
    diagnostics.records{regIndex} = records;
    fprintf('  reference N=%4d  E=%.12e  PG %.3e -> %.3e  tail=%.3e\n', ...
        N_ref, referenceResult.energy, referenceResult.diagnostics.pg_before_polish, ...
        referenceResult.diagnostics.pg_after_polish, ...
        referenceResult.diagnostics.tail_indicator);
end

parameters = baseConfig.parameters;
parameters.N_list = N_list;
parameters.N_ref = N_ref;
solver = baseConfig.solver;
archive.parameters = parameters;
archive.regularization = regularization;
archive.grid = grid;
archive.solver = solver;
archive.rho = rho;
archive.energy = energy;
archive.diagnostics = diagnostics;
archive.history = history;

if save_result
    baseName = sprintf('mesh_refinement_Nref%d_eps_%s.mat', ...
        N_ref, strrep(sprintf('%.0e', epsilon), '-', 'm'));
    result_file = experiments.SaveResult( ...
        archive, 'mesh_refinement', baseName, overwrite_existing);
    if ~isempty(result_file)
        fprintf('saved: %s\n', result_file);
    end
end
if show_plot && save_result && exist('result_file', 'var') && ~isempty(result_file)
    run(fullfile(root, 'post', 'post_mesh_refinement.m'));
end

function record = emptyRecord()
record.N = NaN;
record.h = NaN;
record.energy = NaN;
record.energy_before_polish = NaN;
record.energy_after_polish = NaN;
record.energy_error = NaN;
record.density_L2_error = NaN;
record.density_Linf_error = NaN;
record.pg_residual = NaN;
record.pg_before_polish = NaN;
record.pg_after_polish = NaN;
record.polish_energy_change = NaN;
record.polish_state_change = NaN;
record.mass_error = NaN;
record.min_density = NaN;
record.tail_indicator = NaN;
record.tail_mass = NaN;
record.tail_max = NaN;
record.iterations = NaN;
record.main_iterations = NaN;
record.polish_iterations = NaN;
record.elapsed_time = NaN;
end

function record = recordFromResult(result)
record = emptyRecord();
record.N = result.grid.N;
record.h = result.grid.h;
record.energy = result.energy;
record.energy_before_polish = result.diagnostics.energy_before_polish;
record.energy_after_polish = result.diagnostics.energy_after_polish;
record.pg_residual = result.diagnostics.pg_residual;
record.pg_before_polish = result.diagnostics.pg_before_polish;
record.pg_after_polish = result.diagnostics.pg_after_polish;
record.polish_energy_change = result.diagnostics.polish_energy_change;
record.polish_state_change = result.diagnostics.polish_state_change;
record.mass_error = result.diagnostics.mass_error;
record.min_density = result.diagnostics.min_density;
record.tail_indicator = result.diagnostics.tail_indicator;
record.tail_mass = result.diagnostics.tail_mass;
record.tail_max = result.diagnostics.tail_max;
record.iterations = result.diagnostics.total_iterations;
record.main_iterations = result.diagnostics.main_iterations;
record.polish_iterations = result.diagnostics.polish_iterations;
record.elapsed_time = result.diagnostics.total_elapsed_time;
end
