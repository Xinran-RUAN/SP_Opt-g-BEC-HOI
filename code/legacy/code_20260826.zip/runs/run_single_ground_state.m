%RUN_SINGLE_GROUND_STATE Solve one configurable discrete ground state.
clearvars; clc;

% -------------------------- editable settings --------------------------
reg_name = 'shift_smooth';
epsilon = 1e-3;
transition_width = epsilon;

entropy_enabled = false;
eta = 0;

beta = 10;
delta = 10;
L = 32;
N = 128;

solver_name = 'auto';
projection_name = 'simplex';

pg_tol = 1e-8;
max_iter = 200000;
polish_mode = 'if_needed';
polish_pg_tol = 1e-12;

show_plot = true;
save_result = true;
overwrite_existing = true;
% -----------------------------------------------------------------------

root = fileparts(fileparts(mfilename('fullpath')));
addpath(root);
startup_HOI();

config = experiments.DefaultConfig();
config.parameters.beta = beta;
config.parameters.delta = delta;
config.parameters.L = L;
config.parameters.N = N;
config.parameters.epsilon = epsilon;
config.regularization.name = reg_name;
config.regularization.epsilon = epsilon;
config.regularization.transition_width = transition_width;
config.entropy.enabled = entropy_enabled;
config.entropy.eta = eta;
if strcmpi(solver_name, 'auto')
    if entropy_enabled && eta > 0
        solver_name = 'fista_cd';
    else
        solver_name = 'spg';
    end
end
config.solver.name = solver_name;
config.solver.projection_name = projection_name;
config.solver.pg_tol = pg_tol;
config.solver.max_iter = max_iter;
config.solver.polish_mode = polish_mode;
config.solver.polish.pg_tol = polish_pg_tol;
config.output.show_plot = show_plot;
config.output.save_result = save_result;
config.output.overwrite_existing = overwrite_existing;

result = experiments.SolveGroundState(config);

active = result.diagnostics.active_set;
fourier = result.diagnostics.fourier_tail;
[~, nearIndex] = min(abs(active.zero_tol_list - 1e-12));
fprintf('\nRegularization : %s\n', reg_name);
fprintf('epsilon        : %.3e\n', epsilon);
fprintf('Entropy        : %s\n', onOff(entropy_enabled && eta > 0));
fprintf('eta            : %.3e\n', eta);
fprintf('Main solver    : %s\n', result.diagnostics.main_solver);
fprintf('Main iter      : %d\n', result.diagnostics.main_iterations);
fprintf('Physical E     : %.15e\n', result.physical_energy);
fprintf('Entropy H      : %.15e\n', result.entropy_value);
fprintf('Augmented E    : %.15e\n', result.augmented_energy);
fprintf('Stationarity   : %.3e\n', result.diagnostics.pg_residual);
fprintf('KKT residual   : %.3e\n', result.diagnostics.kkt_residual);
fprintf('Min density    : %.3e\n', min(result.rho));
fprintf('Exact zeros    : %d\n', active.exact_zero_count);
fprintf('Near-zero frac : %.3e\n', active.zero_fraction_by_tol(nearIndex));
fprintf('FFT tail ratio : %.3e\n', fourier.tail_ratio_quarter);
fprintf('Polish         : %s\n', result.diagnostics.polish_status);
fprintf('Polish iter    : %d\n', result.diagnostics.polish_iterations);
fprintf('Mass error     : %.3e\n', result.diagnostics.mass_error);
fprintf('Tail mass      : %.3e\n', result.diagnostics.tail_mass);

if show_plot
    figure('Name', '1D HOI ground-state density');
    plot(result.grid.x, result.rho, 'LineWidth', 1.4);
    xlabel('x'); ylabel('\rho'); grid on;
    title(sprintf('%s, N=%d, \\epsilon=%.1e', reg_name, N, epsilon), ...
        'Interpreter', 'none');
end

if save_result
    baseName = sprintf('single_%s_N%d_eps_%s.mat', ...
        reg_name, N, strrep(sprintf('%.0e', epsilon), '-', 'm'));
    savedFile = experiments.SaveResult( ...
        result, 'single', baseName, overwrite_existing);
    if ~isempty(savedFile)
        fprintf('saved: %s\n', savedFile);
    end
end

function label = onOff(active)
if active
    label = 'on';
else
    label = 'off';
end
end
