%RUN_ENTROPY_MESH_REFINEMENT Fixed-eta augmented-problem mesh study.
clearvars; clc;

% -------------------------- editable settings --------------------------
eta = 1e-3;
epsilon = 1e-3;
N_list = [32, 64, 128, 256, 512];
N_ref = 1024;
L = 32;
beta = 10;
delta = 10;
pg_tol = 1e-8;
polish_kkt_tol = 1e-10;
max_iter = 200000;
save_result = true;
overwrite_existing = false;
% -----------------------------------------------------------------------

if eta <= 0 || any(mod(N_list, 2) ~= 0) || mod(N_ref, 2) ~= 0 ...
        || N_ref <= max(N_list)
    error('Use eta>0 and even meshes with N_ref > max(N_list).');
end
root = fileparts(fileparts(mfilename('fullpath')));
addpath(root);
startup_HOI();
config = experiments.DefaultConfig();
config.parameters.beta = beta;
config.parameters.delta = delta;
config.parameters.L = L;
config.parameters.epsilon = epsilon;
config.regularization.name = 'shift_smooth';
config.regularization.epsilon = epsilon;
config.regularization.transition_width = epsilon;
config.entropy.enabled = true;
config.entropy.eta = eta;
config.solver.name = 'fista_cd';
config.solver.pg_tol = pg_tol;
config.solver.max_iter = max_iter;
config.solver.polish_mode = 'always';
config.solver.polish.pg_tol = polish_kkt_tol;
config.solver.display = false;

allN = [N_list, N_ref];
solutions = cell(numel(allN), 1);
warmStart = [];
coarseProblem = [];
for j = 1:numel(allN)
    config.parameters.N = allN(j);
    fineGrid = model.SetupGrid1D(config.parameters);
    if ~isempty(warmStart)
        coarseProblem.grid = fineGrid;
        coarseProblem.plan = src.discretization.ps.Plan1D(fineGrid);
        warmStart = experiments.TransferState1D( ...
            warmStart, fineGrid, config.parameters.mass, ...
            coarseProblem, config.solver);
    end
    solutions{j} = experiments.SolveGroundState(config, warmStart);
    warmStart = solutions{j}.rho;
    coarseProblem = solutions{j}.problem;
    if ~solutions{j}.diagnostics.polish_converged
        warning('N=%d lacks strict entropy KKT certification (%s).', ...
            allN(j), solutions{j}.diagnostics.polish_status);
    end
end

reference = solutions{end};
records = repmat(emptyMeshRecord(), numel(N_list), 1);
for j = 1:numel(N_list)
    comparison = experiments.CompareStates( ...
        solutions{j}.rho, reference.rho, reference.grid);
    records(j).N = N_list(j);
    records(j).augmented_energy_error = abs( ...
        solutions{j}.augmented_energy - reference.augmented_energy);
    records(j).physical_energy_difference = ...
        solutions{j}.physical_energy - reference.physical_energy;
    records(j).density_L2_error = comparison.density_L2_error;
    records(j).density_Linf_error = comparison.density_Linf_error;
    records(j).kkt_residual = solutions{j}.diagnostics.kkt_residual;
    records(j).fft_tail_ratio = ...
        solutions{j}.diagnostics.fourier_tail.tail_ratio_quarter;
    records(j).tail_mass = solutions{j}.diagnostics.tail_mass;
    records(j).tail_max = solutions{j}.diagnostics.tail_max;
end

fprintf('\nfixed eta=%.3e mesh refinement (reference N=%d)\n', eta, N_ref);
fprintf('N      dEaug       dEphys      L2          Linf        KKT         FFT_tail\n');
for j = 1:numel(records)
    fprintf('%4d  %.3e  %+.3e  %.3e  %.3e  %.3e  %.3e\n', ...
        records(j).N, records(j).augmented_energy_error, ...
        records(j).physical_energy_difference, records(j).density_L2_error, ...
        records(j).density_Linf_error, records(j).kkt_residual, ...
        records(j).fft_tail_ratio);
end
if reference.diagnostics.tail_indicator > 1e-8
    warning('Boundary tail is not negligible; increase L before interpreting Fourier convergence.');
end

archive.parameters = config.parameters;
archive.parameters.N_list = N_list;
archive.parameters.N_ref = N_ref;
archive.parameters.eta = eta;
archive.regularization = reference.regularization;
archive.grid = cellfun(@(s) s.grid, solutions, 'UniformOutput', false);
archive.solver = config.solver;
archive.rho = cellfun(@(s) s.rho, solutions, 'UniformOutput', false);
archive.energy = cellfun(@(s) s.physical_energy, solutions);
archive.physical_energy = archive.energy;
archive.entropy_value = cellfun(@(s) s.entropy_value, solutions);
archive.augmented_energy = cellfun(@(s) s.augmented_energy, solutions);
archive.diagnostics.records = records;
archive.diagnostics.reference = reference.diagnostics;
archive.history = cellfun(@(s) s.history, solutions, 'UniformOutput', false);
if save_result
    experiments.SaveResult(archive, 'entropy_mesh', ...
        sprintf('entropy_mesh_eta_%s_Nref%d.mat', ...
        strrep(sprintf('%.0e', eta), '-', 'm'), N_ref), overwrite_existing);
end

function record = emptyMeshRecord()
record.N = NaN;
record.augmented_energy_error = NaN;
record.physical_energy_difference = NaN;
record.density_L2_error = NaN;
record.density_Linf_error = NaN;
record.kkt_residual = NaN;
record.fft_tail_ratio = NaN;
record.tail_mass = NaN;
record.tail_max = NaN;
end
