%POST_MESH_REFINEMENT Read a saved mesh study and create diagnostic plots.
root = fileparts(fileparts(mfilename('fullpath')));
if ~exist('result_file', 'var') || isempty(result_file)
    files = dir(fullfile(root, 'results', 'mesh_refinement', '*.mat'));
    if isempty(files)
        error('No saved mesh-refinement result was found.');
    end
    [~, newest] = max([files.datenum]);
    result_file = fullfile(files(newest).folder, files(newest).name);
end
data = load(result_file);
names = data.regularization.names;

figure('Name', 'HOI mesh-refinement diagnostics');
tiles = tiledlayout(2, 2, 'TileSpacing', 'compact');
nexttile; hold on;
for j = 1:numel(names)
    records = data.diagnostics.records{j};
    loglog([records.N], [records.energy_error], '-o', 'DisplayName', names{j});
end
xlabel('N'); ylabel('|E_N-E_{ref}|'); grid on; legend('Location', 'best');

nexttile; hold on;
for j = 1:numel(names)
    records = data.diagnostics.records{j};
    loglog([records.N], [records.density_L2_error], '-o', ...
        'DisplayName', names{j});
end
xlabel('N'); ylabel('density L^2 error'); grid on; legend('Location', 'best');

nexttile; hold on;
for j = 1:numel(names)
    modes = abs(data.diagnostics.fourier_modes{j});
    coefficients = abs(data.diagnostics.fourier_coefficients{j});
    [modes, order] = sort(modes);
    semilogy(modes, coefficients(order), '.', 'DisplayName', names{j});
end
xlabel('|Fourier mode|'); ylabel('|c_k|'); grid on; legend('Location', 'best');

nexttile; hold on;
for j = 1:numel(names)
    records = data.diagnostics.records{j};
    loglog([records.N], [records.pg_residual], '-o', 'DisplayName', names{j});
end
xlabel('N'); ylabel('projected-gradient residual'); grid on;
legend('Location', 'best');
title(tiles, sprintf('Mesh refinement, reference N=%d', data.parameters.N_ref));
