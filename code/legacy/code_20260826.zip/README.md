# Convex optimization of the 1D HOI density formulation

This directory is the active, package-based MATLAB implementation. The
original `Code-DensityFormulation/` scripts, `Data/`, and `Figure/` are kept
unchanged as legacy/reference material.

## Model

On the periodic collocation grid

```matlab
h = 2*L/N;
x = -L + (0:N-1)'*h;
```

the code minimizes

\[
E_h(\rho)=h\sum_j\left[
\frac{(D\rho)_j^2}{8s_\varepsilon(\rho_j)}+V_j\rho_j
+\frac{\beta}{2}\rho_j^2+\frac{\delta}{2}(D\rho)_j^2
\right]
\]

subject to nodal (collocation-point) positivity and fixed mass,
\(\rho_j\ge 0\) and \(h\sum_j\rho_j=1\). This project performs convex
optimization of the regularized density formulation with positivity- and
mass-preserving Fourier pseudospectral discretization. The baseline energy
has no biharmonic penalty, filter, or modified potential term.

The active convexity-preserving denominators are:

- `shift_smooth`: \(s=\rho+\varepsilon\);
- `piecewise_c1`, `piecewise_c2`, `piecewise_c3`: the concave transition
  formulas implemented by `src.regularization.EvaluateDenominator`.

The old \(\sqrt{\rho^2+\varepsilon^2}\) denominator is not selectable by
the active solver. Energy and gradient always call the same regularization
implementation.

## Layout

```text
+model/                    parameters, grid, potential, initial density
+src/+regularization/      active denominator definitions and validation
+src/+discretization/+ps/  Fourier plan, D, D^T, energy, gradient, transfer
+src/+constraints/         mass/feasibility and two independent projections
+src/+entropy/             entropy value/derivatives, simplex prox, KKT
+src/+diagnostics/         active-set/support and Fourier-tail evidence
+src/+solvers/             ISTA, SPG, FISTA-CD, residuals, two polishers
+experiments/              configuration, assembly, transfer, save schema
runs/                      supported solver and discretization experiments
post/                      read-only plotting of saved studies
tests/                     low-cost numerical verification
results/                   single, mesh, regularization, diagnostics
legacy/                    pointer to retained original code
```

## Running

Start MATLAB in this directory and initialize paths once:

```matlab
startup_HOI
```

The supported entries are:

```matlab
run('runs/run_single_ground_state.m')
run('runs/run_gradient_consistency.m')
run('runs/run_projection_equivalence.m')
run('runs/run_solver_comparison.m')
run('runs/run_mesh_refinement.m')
run('runs/run_regularization_comparison.m')
run('runs/run_entropy_active_set_sweep.m')
run('runs/run_entropy_mesh_refinement.m')  % only after inspecting the sweep
```

Each run keeps its editable parameters together at the top. For a single
change, edit only the corresponding value there (for example `N`,
`reg_name`, `epsilon`, `solver_name`, or `projection_name`).

## Optimization architecture

- `ISTA` is the reference projected-gradient method for correctness and
  small-problem comparisons.
- `SPG` is the default first-stage convex minimizer. It uses safeguarded BB
  step lengths and a nonmonotone projected line search.
- `FISTA-CD` is an optional accelerated first-order comparison, not the
  production default. Its feasibility and monotone restarts mean that no
  complete unrestarted-FISTA rate claim is made here.
- `PDAS / semismooth Newton` is the optional high-accuracy matrix-free KKT
  polish used after a first-order method enters the local region.

The word **spectral** in SPG refers to the Barzilai-Borwein spectral step
length and is unrelated to the Fourier pseudospectral spatial
discretization.

All methods stop and compare using one fixed-step projected-gradient
residual (`residual_step = 1`). Energy or state plateaus are diagnostics,
not stationarity certificates. The default pipeline is:

```text
SPG (PG about 1e-8) -> optional PDAS polish (PG about 1e-12)
```

### Vanishing entropy option

The optional term

\[
\eta H_h(\rho)=\eta h\sum_j\rho_j(\log\rho_j-1)
\]

is a **computational regularization**, not a new physical term. Setting
`entropy.enabled = false` or `entropy.eta = 0` recovers the original convex
density problem and its existing simplex-projection path. For `eta>0`, the
first-order method uses FISTA-CD (or reference ISTA) with an
entropy-simplex composite prox. Its optional interior equality-constrained
Newton polish does not use the PDAS active-set classifier. Convexity is
preserved.

This branch is designed to test whether removal of the artificial active
set improves Fourier spatial regularity. It does not assume that entropy
restores spectral accuracy. Entropy bias and same-`eta` spatial error must
be studied separately, and finite-box tails must be checked before a
Fourier-convergence interpretation. Classic SPG and PDAS remain the
`eta=0` baseline.

The default mesh study uses `N_list = [32 64 128 256 512]` and
`N_ref = 1024`. Every coarse minimizer is spectrally prolonged to the
reference grid before density errors are computed. Tail mass and tail
maximum are saved separately so a finite-box plateau is not mislabeled as
Fourier error. Energy and PG residuals before and after PDAS, together with
the polish energy/state changes, are saved for every mesh. The full study
is intentionally started only by:

```matlab
run('runs/run_mesh_refinement.m')
```

The regularization study fixes the spatial grid and decreases `epsilon`
from large to small with a simple warm start:

```matlab
run('runs/run_regularization_comparison.m')
```

Mesh and regularization results are saved separately. Files in `post/`
only load saved MAT files and plot; they never invoke a solver. The observed
spectral behavior of smooth versus piecewise regularization is a numerical
study here, not a stated theorem.

## Tests

```matlab
run('tests/run_all_tests.m')
```

The suite checks Fourier differentiation/skew-adjointness, zero-padding
prolongation, projection equivalence, centered energy-gradient consistency,
matrix-free Hessian consistency, random discrete convexity, SPG feasibility
and descent, and small-problem PDAS stationarity improvement for all active
regularizations where applicable.
